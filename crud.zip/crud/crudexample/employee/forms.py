from django import forms  

from employee.models import Employee 
from .models import Details,Reminder
 
class detailsform(forms.ModelForm):
    class Meta:
        model=Details
        fields="__all__"


class EmployeeForm(forms.ModelForm):  
    class Meta:  
        model = Employee  
        fields = "__all__"  


class Reminderform(forms.ModelForm):  
    class Meta:  
        model = Reminder  
        fields = "__all__"  