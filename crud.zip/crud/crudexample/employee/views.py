from asyncore import write
from datetime import datetime
from sqlite3 import Date
from unicodedata import name
from urllib import response
from django.shortcuts import render, redirect
from .models import Details,Reminder
from .forms import  detailsform,Reminderform
from django.http import HttpResponse
import csv
from time import gmtime, strftime

#DataFlair
def index(request):
    shelf = Details.objects.all()
    return render(request, 'index.html', {'shelf': shelf})

def upload(request):
    form = detailsform()
    if request.method == 'POST':
        upload = detailsform(request.POST, request.FILES)
        if upload.is_valid():
            upload.save()
            return redirect('index')
        else:
            return HttpResponse("""your form is wrong, reload on <a href = "{{ url : 'index'}}">reload</a>""")
    else:
        return render(request, 'xyz.html', {'form':form})

def update_Details(request,pk):
    
   product = Details.objects.get(id=pk)

   form = detailsform(instance=product)

   if request.method == 'POST':
        form = detailsform(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return redirect('index')
   
   

        
   return render(request, 'xyz.html',{'form':form})

def delete_Details(request, id):
    id = int(id)
    try:
        Details_sel = Details.objects.get(id = id)
    except Details.DoesNotExist:
        return redirect('index')
    Details_sel.delete()
    return redirect('index')



def export_csv(request):
    date= datetime.now()
    response=  HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment;  filename=Employee.csv' 
    writer= csv.writer(response)
    writer.writerow(['name','email','contact','city','state','country','image','address'])

    expenses= Details.objects.all()
    for expense in expenses:
        writer.writerow([expense.name, expense.email, expense.contact, expense.city, expense.state,expense.country,expense.image, expense.address])
    return response  





def index1(request):
    shelf1 = Reminder.objects.all().order_by('-Date')
    return render(request, 'edit.html', {'shelf1': shelf1})




def upload1(request):
    
    if request.method== "POST":
         form = Reminderform(request.POST)
         if form.is_valid():
                form.save()
                return redirect('index1')
       
    else:
        form = Reminderform()
        
  
    return render(request, "yz.html" ,{'form':form, })


def update1(request,pk):

   product = Reminder.objects.get(id=pk)

   form = Reminderform(instance=product)

   if request.method == 'POST':
        form = Reminderform(request.POST, instance=product)
        if form.is_valid():
            form.save()
            return redirect('index1')
   
   

        
   return render(request, 'yz.html',{'form':form})
    

#def update(request):
def delete(request, id):
    id = int(id)
    try:
        Details_sel = Reminder.objects.get(id = id)
    except Details.DoesNotExist:
        return redirect('index1')
    Details_sel.delete()
    return redirect('index1')




def today(request):
    currendate = strftime("%Y-%m-%d" )
    shelf1 = Reminder.objects.filter(Date = currendate)
    return render(request, 'show.html', {'shelf1': shelf1})


