from django.urls import path
from . import views
from crudexample.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name = 'index'),
    path('upload/', views.upload, name = 'upload-book'),
    path('today/', views.today,),
    path('update/<int:pk>', views.update_Details),
    path('delete/<int:id>', views.delete_Details),
    path('export/', views.export_csv, name='export-csv'),
    path('index1/', views.index1, name = 'index1'),
    path('upload1/', views.upload1, name = 'upload1'),
    path('update1/<int:pk>', views.update1),
    path('delete1/<int:id>', views.delete),
]

#DataFlair
if DEBUG:
    urlpatterns += static(STATIC_URL, document_root = STATIC_ROOT)
    urlpatterns += static(MEDIA_URL, document_root = MEDIA_ROOT)