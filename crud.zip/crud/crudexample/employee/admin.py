
from django.contrib import admin
from .models import Employee,Details,Reminder
#from import_export.admin import ImportExportModelAdmin


"""@admin.register(Details)
class DetailsAdmin(ImportExportModelAdmin):
    pass"""

# Register your models here.
"""@admin.register(Details)
class DetailsAdmin(ImportExportModelAdmin):
   # list_display= ('name', 'email', 'contact', 'address','city', 'state','image','country' )

"""
admin.site.register(Employee)
 
admin.site.register(Details)

admin.site.register(Reminder)

