

from pyexpat import model
from sqlite3 import Time
from unittest.util import _MAX_LENGTH
from django.db import models


class Employee(models.Model):  
   # id = models.CharField(primary_key =True,max_length=20)  
    name = models.CharField(max_length=100)  
    email = models.EmailField()  
    image = models.ImageField()
    address=  models.CharField(max_length=100)
    contact = models.CharField(max_length=15)  
    city= models.CharField(max_length=20)
    state=  models.CharField( max_length=50)
    country= models.CharField(max_length=30)
    
    class Meta:  
        db_table = "employee"  



class Details(models.Model):
    name=models.CharField(max_length=100)
    email = models.EmailField()  
    image = models.ImageField()
    address=  models.TextField(max_length=100)
    contact = models.CharField(max_length=15)  
    city= models.CharField(max_length=20)
    state=  models.CharField( max_length=50)
    country= models.CharField(max_length=30)



class Reminder(models.Model):
    Title= models.CharField(max_length=15)
    Desc= models.TextField(max_length=100)
    Date= models.DateTimeField()
    Time= models.TimeField()
    Remark= models.TextField(max_length=100)
